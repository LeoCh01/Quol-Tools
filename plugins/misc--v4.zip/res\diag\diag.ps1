param(
    [switch]$Live
)

$ErrorActionPreference = 'SilentlyContinue'

function To-GB([double]$bytes) {
    return [math]::Round($bytes / 1GB, 1)
}

function To-Mb([double]$bytes) {
    return [math]::Round($bytes / 1MB)
}

$result = @{}

# ─────────────────────────────────────────────
# LIVE metrics (refresh on a timer)
# ─────────────────────────────────────────────
$cpuLoad = $null
$cpuPerf = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'"
if ($cpuPerf) { $cpuLoad = [double]$cpuPerf.PercentProcessorTime }

$os = Get-CimInstance Win32_OperatingSystem
$memFree = $null; $memTotal = $null
if ($os) {
    $memFree = $os.FreePhysicalMemory * 1KB
    $memTotal = $os.TotalVisibleMemorySize * 1KB
}

# Disk IO (all local drives aggregated)
$diskRead = $null; $diskWrite = $null
$diskPerf = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'"
if ($diskPerf) {
    $diskRead = $diskPerf.DiskReadBytesPersec
    $diskWrite = $diskPerf.DiskWriteBytesPersec
}

# Network throughput + online status
$netRx = $null; $netTx = $null
$netPerf = Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface
if ($netPerf) {
    $netRx = ($netPerf | Measure-Object -Property BytesReceivedPersec -Sum).Sum
    $netTx = ($netPerf | Measure-Object -Property BytesSentPersec -Sum).Sum
}
$online = $false
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        })[0]
    function Await($WinRtTask, $ResultType) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
        $netTask.Result
    }
    $null = [Type]::GetType('Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType=WindowsRuntime', $true)
    $prof = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
    if ($prof) {
        $level = $prof.GetNetworkConnectivityLevel()
        $online = $level.ToString() -eq 'InternetAccess'
    }
} catch { }

# Battery (live, picks up plug/unplug)
$batt = Get-CimInstance Win32_Battery
$battery = $null
if ($batt) {
    $battery = @{
        percent   = [int]$batt.EstimatedChargeRemaining
        charging  = ($batt.BatteryStatus -notin 1, 2)
        present   = $true
    }
}

# Processes
$procs = Get-Process
$topCpu = @($procs | Sort-Object CPU -Descending | Select-Object -First 5 | ForEach-Object {
        @{ name = $_.ProcessName; cpu = [math]::Round($_.CPU, 1); ramMb = To-Mb ([double]$_.WorkingSet64) }
    })
$topRam = @($procs | Sort-Object WorkingSet64 -Descending | Select-Object -First 5 | ForEach-Object {
        @{ name = $_.ProcessName; cpu = [math]::Round($_.CPU, 1); ram = To-Mb ([double]$_.WorkingSet64) }
    })

$result.cpuLoad = $cpuLoad
$result.memFree = $memFree
$result.memTotal = $memTotal
$result.diskRead = $diskRead
$result.diskWrite = $diskWrite
$result.netRx = $netRx
$result.netTx = $netTx
$result.online = $online
$result.battery = $battery
$result.processCount = @($procs).Count
$result.topCpu = $topCpu
$result.topRam = $topRam

if ($Live) {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::Out.WriteLine((ConvertTo-Json -InputObject $result -Compress -Depth 6))
    exit 0
}

# ─────────────────────────────────────────────
# STATIC / hardware info (one-shot)
# ─────────────────────────────────────────────
$cs = Get-CimInstance Win32_ComputerSystem
$bios = Get-CimInstance Win32_BIOS
$board = Get-CimInstance Win32_BaseBoard
$processor = Get-CimInstance Win32_Processor | Select-Object -First 1
$vc = Get-CimInstance Win32_VideoController | Where-Object { $_.Name } | Select-Object -First 3

$gpuUtil = $null
$gpuPerf = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine 2>$null
if ($gpuPerf) {
    $gpuUtil = [math]::Round((($gpuPerf | Where-Object { $_.EngineType -match '3D|Compute' } |
        Measure-Object -Property UtilizationPercentage -Sum).Sum), 1)
}

$result.uptime = $null
if ($os -and $os.LastBootUpTime) {
    $result.uptime = ((Get-Date) - $os.LastBootUpTime).TotalSeconds
}

$result.os = @{
    name    = "$($os.Caption) $($os.OSArchitecture)"
    version = $os.Version
    build   = $os.BuildNumber
    install = if ($os.InstallDate) { $os.InstallDate.ToString('yyyy-MM-dd') } else { $null }
    user    = $env:USERNAME
}
$result.machine = @{
    manufacturer = $cs.Manufacturer
    model        = $cs.Model
    serial       = $bios.SerialNumber
    bios         = "$($bios.SMBIOSBIOSVersion) ($($bios.ReleaseDate.ToString('yyyy')) )".Trim()
    totalRamGb   = To-Gb ([double]$cs.TotalPhysicalMemory)
}
$result.cpu = @{
    name     = $processor.Name
    cores    = $processor.NumberOfCores
    threads  = $processor.NumberOfLogicalProcessors
    maxMhz   = $processor.MaxClockSpeed
}
$result.ramModules = @(@(Get-CimInstance Win32_PhysicalMemory) | ForEach-Object {
        @{ capGb = To-Gb ([double]$_.Capacity); speed = $_.ConfiguredClockSpeed }
    })
$result.gpu = @(@($vc) | ForEach-Object {
        @{
            name     = $_.Name
            vramMb   = if ($_.AdapterRAM) { [int]($_.AdapterRAM / 1MB) } else { $null }
            driver   = $_.DriverVersion
            loadPct  = $gpuUtil
        }
    })
$result.disks = @(@(Get-CimInstance Win32_DiskDrive | Where-Object { $_.Model }) | ForEach-Object {
        @{ model = $_.Model; sizeGb = To-Gb ([double]$_.Size) }
    })
$result.volumes = @(@(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3") | ForEach-Object {
        @{
            id     = $_.DeviceID
            totalGb = To-Gb ([double]$_.Size)
            freeGb  = To-Gb ([double]$_.FreeSpace)
        }
    })
$result.netAdapters = @(@(Get-CimInstance Win32_NetworkAdapter |
        Where-Object { $_.PhysicalAdapter -and $_.NetEnabled }) | ForEach-Object {
        @{
            name      = ($_.NetConnectionID + ' (' + $_.Name + ')')
            mac       = $_.MACAddress
            speedMbps = if ($_.Speed) { [int]($_.Speed / 1MB) } else { $null }
        }
    })

$json = ConvertTo-Json -InputObject $result -Compress -Depth 6
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::Out.WriteLine($json)
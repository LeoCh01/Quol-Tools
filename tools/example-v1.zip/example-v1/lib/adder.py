def add_to_str(a, b):
    return f'{a} + {b} = {a + b}'

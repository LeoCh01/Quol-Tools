def add_to_str(a, b):
    return str(a + b)
